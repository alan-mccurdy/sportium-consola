# Copiloto JobAny (Sportium) — extension de Edge/Chrome

Copiloto de soporte con IA que corre **sobre Chatra**. El agente selecciona el mensaje del cliente y la IA (el mismo cerebro de la consola) sugiere la respuesta. **Humano en el medio: nunca envia solo.**

## Como funciona
- **Leer el mensaje del cliente**: selecciona el texto en el chat y pulsa **Sugerir** en el panel (abajo a la derecha), o clic derecho sobre la seleccion -> **Sugerir respuesta (JobAny)**. Tambien puedes pegar el mensaje en la caja.
- **IA**: llama al webhook `sportium-chat` (mismo cerebro de la consola). Muestra la respuesta sugerida al cliente; con **Detalle** ves el analisis interno (no enviar tal cual al cliente).
- **Login**: el copiloto **reusa tu sesion de la consola**. Abre la consola JobAny e inicia sesion una vez en este navegador; el copiloto toma ese token (y lo refresca solo). No reimplementa el magic-link.
- **Poner en respuesta**: intenta escribir en el cuadro de Chatra (configura el selector en Ajustes para que sea exacto); si no, copia al portapapeles para pegar con Ctrl+V.

## Cargar en Edge
1. Abre `edge://extensions`.
2. Activa "Modo de desarrollador".
3. "Cargar desempaquetada" -> selecciona la carpeta `copiloto-chatra/`.
4. Abre la **consola JobAny** e inicia sesion (https://alan-mccurdy.github.io/sportium-consola/).
5. Abre `https://app.chatra.io/`, entra a un chat: aparece el panel **Copiloto JobAny**.

## Ajustes (icono de la extension -> Ajustes)
- **Pais / vertiente** por defecto (contexto que usa la IA).
- **Selector del mensaje del cliente** (opcional): para auto-leer el ultimo mensaje.
- **Selector del cuadro de respuesta** (opcional): para que "Poner en respuesta" escriba directo en Chatra.
  - Para obtenerlos: en Chatra, F12 -> clic derecho sobre el elemento -> Copy -> Copy selector.

## Notas
- La anon key incluida es **publica por diseno** (ya esta en el HTML publico de la consola); limitada por RLS.
- Si Chatra bloquea el panel por CSP, usa el flujo de **clic derecho** (menu contextual), que no inyecta panel.
- Si Chatra cambia su DOM, ajusta los selectores en Ajustes (no hay que tocar codigo).
