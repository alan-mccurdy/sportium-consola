// Service worker: maneja la sesion (reusa la de la consola), llama a la IA (webhook
// sportium-chat) y el menu contextual "Sugerir respuesta". Humano en el medio: solo sugiere.
importScripts('config.js');

// ---------- sesion ----------
async function getSession() { const r = await chrome.storage.local.get('jobany_session'); return r.jobany_session || null; }
async function setSession(s) { await chrome.storage.local.set({ jobany_session: s }); }
async function getCfg() { const r = await chrome.storage.local.get('jobany_cfg'); return r.jobany_cfg || { pais: 'MX', vertical: 'online', clientSel: '', replySel: '' }; }

async function getValidToken() {
  const s = await getSession();
  if (!s || !s.access_token) return null;
  const now = Math.floor(Date.now() / 1000);
  if (s.expires_at && (s.expires_at - 60) > now) return s.access_token;   // aun vigente
  if (s.refresh_token) {
    try {
      const r = await fetch(JOBANY.SUPA + '/auth/v1/token?grant_type=refresh_token', {
        method: 'POST', headers: { apikey: JOBANY.ANON, 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: s.refresh_token })
      });
      if (r.ok) {
        const j = await r.json();
        const ns = { access_token: j.access_token, refresh_token: j.refresh_token || s.refresh_token, expires_at: j.expires_at || (now + (j.expires_in || 3600)), email: (j.user && j.user.email) || s.email };
        await setSession(ns); return ns.access_token;
      }
    } catch (e) {}
  }
  return s.access_token;   // ultimo recurso (el webhook dira si ya no sirve)
}

// ---------- extraer la respuesta al cliente de los 3 bloques ----------
function extraerSugerida(txt) {
  if (!txt) return '';
  const m = txt.match(/respuesta\s+(?:sugerida\s+)?al\s+cliente\s*:?\s*([\s\S]*)/i);
  let out = m ? m[1] : txt;
  out = out.replace(/^["“”\s]+|["“”\s]+$/g, '').trim();
  return out || txt.trim();
}

// ---------- llamar a la IA ----------
async function callIA(text) {
  const token = await getValidToken();
  if (!token) return { ok: false, reason: 'no_auth', error: 'Inicia sesion: abre la consola JobAny y entra con tu correo (el copiloto reusa esa sesion).' };
  const cfg = await getCfg();
  const body = {
    mensajes: [{ role: 'user', content: text }],
    pais: cfg.pais || 'MX',
    turno: { pais: cfg.pais || 'MX', vertical: cfg.vertical || 'online' },
    tenant: JOBANY.TENANT, empresa: { nombre: 'Sportium' }, canal: 'chatra'
  };
  try {
    const r = await fetch(JOBANY.WEBHOOK, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token }, body: JSON.stringify(body) });
    const raw = (await r.text() || '').trim();
    if (!r.ok) return { ok: false, error: 'Servidor ' + r.status + (raw ? (': ' + raw.slice(0, 140)) : '') };
    let d; try { d = JSON.parse(raw); if (Array.isArray(d)) d = d[0]; } catch (_) { d = { respuesta: raw }; }
    const resp = (d && (d.respuesta || d.output || d.text || d.message)) || '';
    if (!resp) return { ok: false, error: 'La IA respondio vacio.' };
    if (/sesion no valida/i.test(resp)) return { ok: false, reason: 'no_auth', error: 'Tu sesion expiro. Abre la consola JobAny y vuelve a entrar.' };
    return { ok: true, respuesta: resp, sugerida: extraerSugerida(resp), modelo: (d && d.modelo) || '' };
  } catch (e) { return { ok: false, error: 'Red: ' + ((e && e.message) || e) }; }
}

// ---------- menu contextual ----------
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: 'jobany-suggest', title: 'Sugerir respuesta (JobAny)', contexts: ['selection'] });
});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== 'jobany-suggest' || !info.selectionText || !tab) return;
  chrome.tabs.sendMessage(tab.id, { type: 'JOBANY_LOADING', q: info.selectionText });
  const res = await callIA(info.selectionText);
  chrome.tabs.sendMessage(tab.id, { type: 'JOBANY_RESULT', q: info.selectionText, res: res });
});

// ---------- mensajes desde content / popup / console-auth ----------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  if (msg.type === 'JOBANY_SESSION' && msg.session) { setSession(msg.session).then(() => sendResponse({ ok: true })); return true; }
  if (msg.type === 'JOBANY_SUGGEST') { callIA(msg.text || '').then(sendResponse); return true; }
  if (msg.type === 'JOBANY_AUTH') { getSession().then(s => sendResponse({ logged: !!(s && s.access_token), email: (s && s.email) || '' })); return true; }
  if (msg.type === 'JOBANY_LOGOUT') { chrome.storage.local.remove('jobany_session').then(() => sendResponse({ ok: true })); return true; }
});
