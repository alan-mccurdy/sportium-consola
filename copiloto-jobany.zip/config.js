// Config compartida (cargada en background, content y popup/options).
// La anon key es PUBLICA por diseno (ya vive en el HTML publico de la consola); limitada por RLS.
var JOBANY = {
  SUPA: 'https://rmcsmxjzvxoybrziplhw.supabase.co',
  ANON: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJtY3NteGp6dnhveWJyemlwbGh3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODEyMDkxMjksImV4cCI6MjA5Njc4NTEyOX0.qqFMgco0dYevjkSZI6D_Gjb0GJrm_sL2uPIEwUHGcgs',
  WEBHOOK: 'https://n8n-production-aff6.up.railway.app/webhook/sportium-chat',
  STORAGE_KEY: 'sb-rmcsmxjzvxoybrziplhw-auth-token',  // donde supabase-js v2 guarda la sesion en la consola
  CONSOLE_URL: 'https://alan-mccurdy.github.io/sportium-consola/',
  TENANT: 'sportium'
};
if (typeof module !== 'undefined') module.exports = JOBANY;
