// Corre en la consola JobAny: lee la sesion de Supabase (localStorage) y la pasa al
// service worker para que el copiloto reuse ese login. No envia nada a terceros.
(function () {
  function read() { try { return localStorage.getItem(JOBANY.STORAGE_KEY); } catch (e) { return null; } }
  function parse(raw) {
    try {
      const o = JSON.parse(raw); const s = (o && o.currentSession) || o;
      if (s && s.access_token) return { access_token: s.access_token, refresh_token: s.refresh_token, expires_at: s.expires_at || s.expiresAt || null, email: (s.user && s.user.email) || (o.user && o.user.email) || '' };
    } catch (e) {}
    return null;
  }
  function push() { const s = parse(read()); if (s && s.access_token) { try { chrome.runtime.sendMessage({ type: 'JOBANY_SESSION', session: s }); } catch (e) {} } }
  push();
  let last = read();
  setInterval(function () { const cur = read(); if (cur !== last) { last = cur; push(); } }, 5000);
  window.addEventListener('storage', function (e) { if (!e.key || e.key === JOBANY.STORAGE_KEY) push(); });
})();
