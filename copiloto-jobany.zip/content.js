// Panel del Copiloto sobre Chatra. Flujo: el agente SELECCIONA el mensaje del cliente
// (o lo pega en la caja) -> "Sugerir" -> la IA (webhook sportium-chat) responde -> el agente
// edita/copia/pone en el cuadro. Humano en el medio: nunca envia solo.
(function () {
  if (document.getElementById('copiloto-sportium')) return;

  var wrap = document.createElement('div');
  wrap.id = 'copiloto-sportium';
  wrap.innerHTML =
    '<div class="cps-head">' +
      '<span class="cps-title">Copiloto JobAny</span>' +
      '<button class="cps-icon" id="cps-collapse" title="Colapsar" aria-label="Colapsar">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg>' +
      '</button>' +
    '</div>' +
    '<div class="cps-body" id="cps-body">' +
      '<div class="cps-note" id="cps-note" style="display:none"></div>' +
      '<div class="cps-label">Mensaje del cliente <span style="opacity:.6">(selecciona el texto en el chat o pegalo)</span></div>' +
      '<textarea class="cps-res" id="cps-q" rows="3" placeholder="Selecciona el mensaje del cliente y pulsa Sugerir, o pegalo aqui."></textarea>' +
      '<div class="cps-row">' +
        '<button class="cps-btn cps-primary" id="cps-suggest">Sugerir respuesta</button>' +
        '<button class="cps-btn" id="cps-fromsel" title="Usar el texto seleccionado">Usar seleccion</button>' +
      '</div>' +
      '<div class="cps-label" style="margin-top:10px">Respuesta sugerida</div>' +
      '<textarea class="cps-res" id="cps-res" rows="6" placeholder="Aqui aparece la sugerencia de la IA. Editala antes de enviar."></textarea>' +
      '<div class="cps-row">' +
        '<button class="cps-btn cps-primary" id="cps-poner">Poner en respuesta</button>' +
        '<button class="cps-btn" id="cps-copy">Copiar</button>' +
        '<button class="cps-btn" id="cps-detalle" title="Ver el analisis interno completo">Detalle</button>' +
      '</div>' +
    '</div>';
  document.body.appendChild(wrap);

  var byId = function (id) { return document.getElementById(id); };
  var fullRespuesta = '';

  // --- toast ---
  var toastT = null;
  function toast(msg) {
    var t = byId('cps-toast');
    if (!t) { t = document.createElement('div'); t.id = 'cps-toast'; t.className = 'cps-toast'; document.body.appendChild(t); }
    t.textContent = msg; t.classList.add('on');
    clearTimeout(toastT); toastT = setTimeout(function () { t.classList.remove('on'); }, 2000);
  }
  function note(html, isErr) { var n = byId('cps-note'); if (!n) return; if (!html) { n.style.display = 'none'; return; } n.style.display = ''; n.className = 'cps-note' + (isErr ? ' err' : ''); n.innerHTML = html; }

  // --- recordar la ultima seleccion del cliente en la pagina (no dentro del panel) ---
  var lastSel = '';
  document.addEventListener('selectionchange', function () {
    try {
      if (wrap.contains(document.activeElement)) return;
      var s = (window.getSelection && window.getSelection().toString() || '').trim();
      if (s) lastSel = s;
    } catch (e) {}
  });

  // --- colapsar ---
  var collapsed = false;
  byId('cps-collapse').addEventListener('click', function () {
    collapsed = !collapsed;
    byId('cps-body').style.display = collapsed ? 'none' : '';
    byId('cps-collapse').classList.toggle('rot', collapsed);
  });
  function expand() { collapsed = false; byId('cps-body').style.display = ''; byId('cps-collapse').classList.remove('rot'); }

  // --- usar seleccion ---
  byId('cps-fromsel').addEventListener('click', function () {
    if (!lastSel) { toast('Primero selecciona el mensaje del cliente en el chat'); return; }
    byId('cps-q').value = lastSel;
  });

  // --- pedir sugerencia a la IA ---
  function pedir() {
    var q = (byId('cps-q').value || '').trim();
    if (!q && lastSel) { q = lastSel; byId('cps-q').value = q; }
    if (!q) { toast('Selecciona o pega el mensaje del cliente'); return; }
    note('');
    var btn = byId('cps-suggest'); btn.disabled = true; var prev = btn.textContent; btn.textContent = 'Generando...';
    byId('cps-res').value = '';
    chrome.runtime.sendMessage({ type: 'JOBANY_SUGGEST', text: q }, function (res) {
      btn.disabled = false; btn.textContent = prev;
      pintarResultado(res);
    });
  }
  byId('cps-suggest').addEventListener('click', pedir);

  function pintarResultado(res) {
    if (!res || !res.ok) {
      if (res && res.reason === 'no_auth') {
        note('Inicia sesion para usar la IA. <a href="#" id="cps-login">Abrir consola JobAny</a>', true);
        var l = byId('cps-login'); if (l) l.addEventListener('click', function (e) { e.preventDefault(); window.open(JOBANY.CONSOLE_URL, '_blank'); });
      } else { note((res && res.error) || 'No se pudo generar la sugerencia.', true); }
      return;
    }
    fullRespuesta = res.respuesta || '';
    byId('cps-res').value = res.sugerida || res.respuesta || '';
    expand();
    toast('Sugerencia lista' + (res.modelo ? ' (' + res.modelo + ')' : ''));
  }

  // --- resultado que llega desde el menu contextual (background) ---
  chrome.runtime.onMessage.addListener(function (msg) {
    if (!msg) return;
    if (msg.type === 'JOBANY_LOADING') { expand(); byId('cps-q').value = msg.q || ''; byId('cps-res').value = ''; note(''); byId('cps-suggest').textContent = 'Generando...'; byId('cps-suggest').disabled = true; }
    if (msg.type === 'JOBANY_RESULT') { byId('cps-suggest').textContent = 'Sugerir respuesta'; byId('cps-suggest').disabled = false; pintarResultado(msg.res); }
  });

  // --- detalle (analisis interno completo) ---
  byId('cps-detalle').addEventListener('click', function () {
    if (!fullRespuesta) { toast('Primero genera una sugerencia'); return; }
    var r = byId('cps-res');
    if (r.value === fullRespuesta) { r.value = (function (t) { var m = t.match(/respuesta\s+(?:sugerida\s+)?al\s+cliente\s*:?\s*([\s\S]*)/i); return m ? m[1].trim() : t; })(fullRespuesta); toast('Solo respuesta al cliente'); }
    else { r.value = fullRespuesta; toast('Analisis interno completo (no enviar al cliente tal cual)'); }
  });

  // --- copiar ---
  byId('cps-copy').addEventListener('click', function () {
    var txt = byId('cps-res').value;
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(function () { toast('Respuesta copiada'); }).catch(function () { toast('Selecciona y copia manual'); });
    else { byId('cps-res').select(); try { document.execCommand('copy'); toast('Respuesta copiada'); } catch (e) { toast('Selecciona y copia manual'); } }
  });

  // --- poner en el cuadro de Chatra (selector configurable; si no, el campo enfocado) ---
  byId('cps-poner').addEventListener('click', function () {
    var txt = byId('cps-res').value; if (!txt) { toast('No hay respuesta que poner'); return; }
    chrome.storage.local.get('jobany_cfg', function (r) {
      var sel = (r && r.jobany_cfg && r.jobany_cfg.replySel) || '';
      var box = null;
      if (sel) { try { box = document.querySelector(sel); } catch (e) {} }
      if (!box) box = document.querySelector('[contenteditable="true"], textarea[name], textarea, .chatra textarea');
      if (!box) { navigator.clipboard && navigator.clipboard.writeText(txt); toast('No encontre el cuadro de Chatra: lo copie, pega con Ctrl+V'); return; }
      box.focus();
      if (box.isContentEditable) { document.execCommand('selectAll', false, null); document.execCommand('insertText', false, txt); }
      else { var setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value'); if (box.tagName === 'TEXTAREA' && setter) setter.set.call(box, txt); else box.value = txt; box.dispatchEvent(new Event('input', { bubbles: true })); }
      toast('Puesto en el cuadro. Revisa y envia tu.');
    });
  });

  // --- aviso inicial si no hay sesion ---
  chrome.runtime.sendMessage({ type: 'JOBANY_AUTH' }, function (a) {
    if (!a || !a.logged) note('Para usar la IA: abre la <a href="#" id="cps-login2">consola JobAny</a> e inicia sesion (el copiloto reusa ese login).', false);
    var l = byId('cps-login2'); if (l) l.addEventListener('click', function (e) { e.preventDefault(); window.open(JOBANY.CONSOLE_URL, '_blank'); });
  });
})();
