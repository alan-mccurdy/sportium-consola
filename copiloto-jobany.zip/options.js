// Ajustes: guarda contexto por defecto + selectores opcionales de Chatra.
var F = ['pais', 'vertical', 'clientSel', 'replySel'];
chrome.storage.local.get('jobany_cfg', function (r) {
  var c = (r && r.jobany_cfg) || { pais: 'MX', vertical: 'online', clientSel: '', replySel: '' };
  F.forEach(function (k) { var el = document.getElementById(k); if (el && c[k] != null) el.value = c[k]; });
});
document.getElementById('save').addEventListener('click', function () {
  var c = {}; F.forEach(function (k) { c[k] = (document.getElementById(k).value || '').trim(); });
  chrome.storage.local.set({ jobany_cfg: c }, function () { var o = document.getElementById('ok'); o.style.display = ''; setTimeout(function () { o.style.display = 'none'; }, 1500); });
});
