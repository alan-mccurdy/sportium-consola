// Popup: muestra el estado de sesion (reusada de la consola) y atajos.
function render(a) {
  var s = document.getElementById('stat');
  if (a && a.logged) { s.className = 'stat ok'; s.innerHTML = '<span class="dot g"></span>Sesion activa' + (a.email ? (': <b>' + a.email + '</b>') : '') + '. Listo para sugerir.'; }
  else { s.className = 'stat no'; s.innerHTML = '<span class="dot r"></span>Sin sesion. Abre la consola e inicia sesion (el copiloto reusa ese login).'; }
}
chrome.runtime.sendMessage({ type: 'JOBANY_AUTH' }, render);
document.getElementById('btnConsola').addEventListener('click', function () { chrome.tabs.create({ url: JOBANY.CONSOLE_URL }); });
document.getElementById('btnOpts').addEventListener('click', function () { if (chrome.runtime.openOptionsPage) chrome.runtime.openOptionsPage(); else chrome.tabs.create({ url: 'options.html' }); });
